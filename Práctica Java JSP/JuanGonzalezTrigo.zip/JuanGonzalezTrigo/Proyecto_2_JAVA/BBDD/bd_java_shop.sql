-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-07-2020 a las 00:23:28
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bd_java_shop`
--
CREATE DATABASE IF NOT EXISTS `bd_java_shop` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `bd_java_shop`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `category_table`
--

CREATE TABLE `category_table` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELACIONES PARA LA TABLA `category_table`:
--

--
-- Volcado de datos para la tabla `category_table`
--

INSERT INTO `category_table` (`id`, `nombre`, `descripcion`) VALUES
(1, 'Sin categoría', NULL),
(2, 'Componente', 'Componenentes internos PC'),
(3, 'Periférico', 'Períferico'),
(4, 'Entretenimiento', 'Equipamiento de ocio'),
(5, 'Profesional', 'Equipamiento profesional'),
(6, 'Gaming', 'Especial para gamers');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product_table`
--

CREATE TABLE `product_table` (
  `id` int(11) NOT NULL,
  `tipo` varchar(45) DEFAULT NULL,
  `marca` varchar(45) DEFAULT NULL,
  `modelo` varchar(45) DEFAULT NULL,
  `descripcion` longtext CHARACTER SET utf8 DEFAULT NULL,
  `gama` varchar(45) DEFAULT NULL,
  `tecnologia` varchar(45) DEFAULT NULL,
  `precio` decimal(6,2) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELACIONES PARA LA TABLA `product_table`:
--

--
-- Volcado de datos para la tabla `product_table`
--

INSERT INTO `product_table` (`id`, `tipo`, `marca`, `modelo`, `descripcion`, `gama`, `tecnologia`, `precio`, `email`, `id_categoria`) VALUES
(1, 'Teclados', 'Corsair', 'K55 RGB', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Advance', 'Wired', '58.95', 'prueba1@mail.com', 3),
(2, 'Ratón', 'Razer', 'Viper Ultimate', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Elite', 'Wired', '149.99', 'prueba2@mail.com', 6),
(3, 'Sillas', 'KingChair', 'Dominator Plus', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Basic', 'Textil', '35.14', 'prueba3@mail.com', 4),
(4, 'Auxiliar', 'Trust', 'DoLight', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Advance', 'LED', '12.15', 'prueba4@mail.com', 2),
(5, 'Streaming', 'Synaptic', 'XC-Deck', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Elite', 'Wireless', '12.15', 'prueba4@mail.com', 3),
(6, 'Componente PC', 'Intel', 'i3 8500', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Basic', 'Intel', '12.15', 'prueba4@mail.com', 4),
(7, 'Teclados', 'Logitech', 'Strike RGB', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Advance', 'Wired', '12.15', 'prueba4@mail.com', 5),
(8, 'Auxiliar', 'Xiaomi', 'Night Light', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Elite', 'LED', '12.15', 'prueba4@mail.com', 6),
(9, 'Componente PC', 'AMD', 'Ryzen 3 3500', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Basic', 'AMD', '12.15', 'prueba4@mail.com', 2),
(10, 'Auxiliar', 'Scale', 'Track Super', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Advance', 'Textil', '12.15', 'prueba4@mail.com', 3),
(11, 'Audio', 'QCY', 'AirDots II', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Basic', 'Wired', '92.99', 'prueba22@mail.com', 4),
(12, 'Sillas', 'Noblechair', 'Xtasis', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Elite', 'Textil', '12.15', 'prueba4@mail.com', 5),
(13, 'Ratones', 'Microsoft', 'Surface Precision', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Advance', 'Wireless', '12.15', 'prueba4@mail.com', 6),
(15, 'Monitores', 'ViewSonic', 'VP2785 2K', 'El monitor VP2785-2K de ViewSonic cuenta con la certificación Fogra \"FograCert Softproof\" Clase A, uno de los estándares más altos de la industria para la calidad visual, y es capaz de ofrecer una calidad de imagen excepcional, asegurando precisión y uniformidad cromático de fotos y gráficos para un resultado final fiel al original.', 'Advance', 'LED', '522.45', 'prueba14@mail.com', 5),
(16, 'Monitores', 'ViewSonic', 'VX2476SMH', 'Ya sea para uso en la oficina o para disfrutar del entretenimiento en el hogar, el ViewSonic® VX2476-SMH está diseñado para llevar su experiencia visual a otro nivel. Con un panel IPS SuperClear® y un diseño elegante sin marco, este monitor ofrece una experiencia de visualización perfecta, ideal para configuraciones de monitores múltiples. La resolución Full HD aumenta la eficiencia y los detalles de imagen necesarios para trabajar o jugar. ', 'Basic', 'LED', '387.25', 'prueba15@mail.com', 3),
(17, 'Ratones', 'Roccat', 'LEADR', 'Leadr te ofrece la libertad de un ratón inalámbrico con el rendimiento de uno con cable. Cuenta con una combinación de tecnología inalámbrica pionera y el sensor óptico optimizado Owl-Eye. Jugar con un ratón inalámbrico ya no volverá a ser una desventaja.', 'Advance', 'Wireless', '125.59', 'prueba16@mail.com', 6),
(18, 'Auxiliar', 'Razer', 'Gigantus V2 Medium', 'Si lo que buscas es jugar partidas increíbles, ve a lo grande con la Razer Gigantus V2. Se trata de una alfombrilla gaming suave para ratón con una superficie de tela texturizada de microtejidos, diseñada para subir de nivel tu juego con movimientos fluidos y precisión a nivel de píxel.', 'Basic', 'Textil', '11.99', 'prueba17@mail.com', 3),
(19, 'Componente PC', 'AMD', 'Ryzen 9 3950XT', 'Fabricados para Rendir. Diseñados para Ganar. El procesador más avanzado que existe con hasta 12 núcleos para los jugadores de élite de todo el mundo.', 'Advance', 'AMD', '707.90', 'prueba18@mail.com', 2),
(20, 'Streaming', 'Stream Deck', 'Elgato', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Advance', 'Wired', '149.95', 'prueba19@mail.com', 5),
(21, 'Auxiliar', 'Corsair', 'iCUE LT100', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut a', 'Basic', 'LED', '69.95', 'prueba20@mail.com', 4);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `category_table`
--
ALTER TABLE `category_table`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `product_table`
--
ALTER TABLE `product_table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `category_table`
--
ALTER TABLE `category_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `product_table`
--
ALTER TABLE `product_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;


--
-- Metadatos
--
USE `phpmyadmin`;

--
-- Metadatos para la tabla category_table
--

--
-- Metadatos para la tabla product_table
--

--
-- Metadatos para la base de datos bd_java_shop
--
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
