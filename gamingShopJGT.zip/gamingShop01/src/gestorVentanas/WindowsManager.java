package gestorVentanas;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import daos.AccesoriosDAO;
import daos.AccesoriosDAOimplFile;
import modelo.Accesorio;
import vista.EditWindow;
import vista.InsertWindow;
import vista.ListWindow;
import vista.MainWindow;

public class WindowsManager extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	AccesoriosDAO accesoriosDAO = new AccesoriosDAOimplFile();

	// Ventanas
	private MainWindow mainWindow = new MainWindow();
	private ImagenFondoPanel imagenFondoPanel = new ImagenFondoPanel();
	private InsertWindow insertWindow = new InsertWindow();
	private ListWindow listWindow = new ListWindow();
	private EditWindow editWindow = new EditWindow();

	// Inicializamos el índice
	int indexSelectedAccesory = -1;

	// CONSTRUCTOR
	public WindowsManager() {

		// ATENDER MENÚS
		mainWindow.getMainMenu().addActionListener(this);
		mainWindow.getMenuRegistrar().addActionListener(this);
		mainWindow.getMenuListar().addActionListener(this);

		// ATENDER BOTONES, CAMPOS DE TEXTO, COMBOBOXES Y RADIO BUTTONS

		// **** VENTANA INSERTAR ACCESORIO ****

		// Comboboxes
		insertWindow.getComboTipo().addActionListener(this);
		insertWindow.getComboGama().addActionListener(this);

		// Campos de texto
		insertWindow.getMarca().addActionListener(this);
		insertWindow.getModelo().addActionListener(this);
		insertWindow.getPrecio().addActionListener(this);

		// Radio buttons
		insertWindow.getRbnSi().addActionListener(this);
		insertWindow.getRbnNo().addActionListener(this);

		// Botón registrar
		insertWindow.getBtnRegistrar().addActionListener(this);

		// ==== END VENTANA INSERTAR ACCESORIO ===

		// **** VENTANA LISTAR ACCESORIOS ****

		// Botones editar y borrar libro
		listWindow.getBtnEditar().addActionListener(this);
		listWindow.getBtnBorrar().addActionListener(this);

		// ==== END VENTANA LISTAR ACCESORIOS ===

		// **** VENTANA EDITAR ACCESORIO ****

		// Comboboxes
		editWindow.getEditComboTipo().addActionListener(this);
		editWindow.getEditComboGama().addActionListener(this);

		// Campos de texto
		editWindow.getEditMarca().addActionListener(this);
		editWindow.getEditModelo().addActionListener(this);
		editWindow.getEditPrecio().addActionListener(this);

		// Radio buttons
		editWindow.getEditRdbtnSi().addActionListener(this);
		editWindow.getEditRdbtnNo().addActionListener(this);

		// Boton guardar cambios
		editWindow.getBtnModificar().addActionListener(this);

		// ==== END VENTANA EDITAR ACCESORIOS ===

		// END ATENDER BOTONES, CAMPOS DE TEXTO, COMBOBOXES Y RADIO BUTTONS

		// MOSTRAR VENTANA PRINCIPAL

		mainWindow.setContentPane(imagenFondoPanel);
		mainWindow.setLocationRelativeTo(null);
		mainWindow.setVisible(true);
		

		// END MOSTRAR VENTANA PRINCIPAL

	} // END CONSTRUCTOR

	@Override
	public void actionPerformed(ActionEvent e) {

		Object selection = e.getSource();
		Accesorio newAccesory = new Accesorio();

		// Selección menú principal
		if (selection == mainWindow.getMainMenu()) {

			mainWindow.setContentPane(imagenFondoPanel);

			// VENTANA INSERTAR ACCESORIO
		} else if (selection == mainWindow.getMenuRegistrar()) {

			loadInsertPanel();

			// VENTANA LISTADO ACCESORIOS
		} else if (selection == mainWindow.getMenuListar()) {

			loadListPanel();

			// ********************* REGISTRAR NUEVO ACCESORIO **********************

		} else if (selection == insertWindow.getBtnRegistrar()) {

			String tipo = null;
			String marca = "";
			String modelo = "";
			String gama = null;
			String precio = "";
			double precioDouble = 0.0;
			boolean correcto = false;

			int indiceTipo = insertWindow.getComboTipo().getSelectedIndex();
			int indiceGama = insertWindow.getComboGama().getSelectedIndex();

			// VALIDAR COMBO TIPO
			System.out.printf("El indice seleccionado es %d\n", indiceTipo);

			if (indiceTipo <= 0) {

				correcto = false;
				JOptionPane.showMessageDialog(null, "Debe elegir una opción de las mostradas", "TIPO DE ACCESORIO",
						JOptionPane.ERROR_MESSAGE);
				return;

			} else if (indiceTipo > 0) {

				tipo = insertWindow.getComboTipo().getSelectedItem().toString();
				correcto = true;
			} // end if indiceTipo

			// VALIDAR MARCA
			marca = insertWindow.getMarca().getText();

			if (!textoValido(marca) || marca.isEmpty()) {

				correcto = false;
				JOptionPane.showMessageDialog(null, "Debe introducir un texto correcto para la marca.",
						"DATO ERRÓNEO MARCA", JOptionPane.ERROR_MESSAGE);
				return;

			} else {

				correcto = true;

			} // end if marca

			// VALIDAR MODELO
			modelo = insertWindow.getModelo().getText();

			if (!textoValido(modelo) || modelo.isEmpty()) {

				correcto = false;
				JOptionPane.showMessageDialog(null, "Debe introducir un texto correcto para el modelo.",
						"DATO ERRÓNEO MODELO", JOptionPane.ERROR_MESSAGE);
				return;

			} else {

				correcto = true;

			} // end if modelo

			// VALIDAR COMBO GAMA
			if (indiceGama <= 0) {

				JOptionPane.showMessageDialog(null, "Debe elegir una opción de las mostradas", "GAMA ACCESORIO",
						JOptionPane.ERROR_MESSAGE);
				return;

			} else if ((indiceGama > 0)) {

				gama = insertWindow.getComboGama().getSelectedItem().toString();
				correcto = true;

			} // end if indiceGama

			// VALIDAR PRECIO

			precio = insertWindow.getPrecio().getText().replace(",", ".");

			if (!decimalValido(precio) || precio.isEmpty()) {

				correcto = false;
				JOptionPane.showMessageDialog(null, "Debe introducir un valor correcto para el precio.",
						"DATO ERRÓNEO PRECIO", JOptionPane.ERROR_MESSAGE);
				return;

			} else {
				precioDouble = Double.parseDouble(precio);
				correcto = true;
			} // END IF VALIDAR PRECIO

			// SELECIÓN DE SOPORTE
			String soporte = "NO";

			if (insertWindow.getRbnSi().isSelected()) {
				soporte = "SI";
			} // END IF SOPORTE

			System.out.println(correcto);

			if (correcto == true) {

				newAccesory.setTipo(tipo);
				newAccesory.setMarca(marca);
				newAccesory.setModelo(modelo);
				newAccesory.setGama(gama);
				newAccesory.setPrecio(precioDouble);
				newAccesory.setSoporte(soporte);

				accesoriosDAO.registrarAccesorio(newAccesory);

				JOptionPane.showMessageDialog(null, "Accesorio registrado correctamente");

				insertWindow.getComboTipo().setSelectedIndex(0);
				insertWindow.getMarca().setText("");
				insertWindow.getModelo().setText("");
				insertWindow.getComboGama().setSelectedIndex(0);
				insertWindow.getPrecio().setText("");
				insertWindow.getRbnNo().setSelected(true);

			} // END IF CORRECTO

			// ********************* EDITAR **********************

		} else if (selection == listWindow.getBtnEditar()) {

			indexSelectedAccesory = listWindow.getListAccesory().getSelectedIndex();

			System.out.printf("Índice de la lista seleccionado %d", indexSelectedAccesory);

			if (indexSelectedAccesory == -1) {

				JOptionPane.showMessageDialog(null, "Debes seleccionar un elemento de la lista.",
						"ELEMENTO NO SELECCIONADO", JOptionPane.ERROR_MESSAGE);
				return;
			} // END IF indexSelectedAccesory

			Accesorio a = accesoriosDAO.obtenerAccesorioPorIndice(indexSelectedAccesory);

			// Mostrar opción guardada del combobox tipo
			String tipo = a.getTipo();

			switch (tipo) {

			case "Audio":

				editWindow.getEditComboTipo().setSelectedIndex(1);

				break;

			case "Teclados":

				editWindow.getEditComboTipo().setSelectedIndex(2);

				break;

			case "Ratones":

				editWindow.getEditComboTipo().setSelectedIndex(3);

				break;

			case "Monitores":

				editWindow.getEditComboTipo().setSelectedIndex(4);

				break;

			case "Streaming":

				editWindow.getEditComboTipo().setSelectedIndex(5);

				break;

			case "Accesorios periféricos":

				editWindow.getEditComboTipo().setSelectedIndex(6);

				break;

			default:

				break;
			}

			// Mostrar marca
			editWindow.getEditMarca().setText(a.getMarca());

			// Mostrar modelo
			editWindow.getEditModelo().setText(a.getModelo());

			// Mostrar opción guardada del combobox gama
			String gama = a.getGama();

			switch (gama) {

			case "Basic":

				editWindow.getEditComboGama().setSelectedIndex(1);

				break;

			case "Advance":

				editWindow.getEditComboGama().setSelectedIndex(2);

				break;

			case "Elite":

				editWindow.getEditComboGama().setSelectedIndex(3);

				break;

			}

			editWindow.getEditPrecio().setText(Double.toString(a.getPrecio()));

			if (a.getSoporte() == "SI") {

				editWindow.getEditRdbtnSi().setSelected(true);
			} else {

				editWindow.getEditRdbtnNo().setSelected(true);
			}

			mainWindow.setContentPane(editWindow);

			// ELIMINAR ACCESORIO
		} else if (selection == listWindow.getBtnBorrar()) {

			int indice = listWindow.getListAccesory().getSelectedIndex();

			System.out.printf("Índice elemento a eliminar %d", indice);

			if (indice == -1) {

				JOptionPane.showMessageDialog(null, "Debes seleccionar un elemento de la lista.",
						"ELEMENTO NO SELECCIONADO", JOptionPane.ERROR_MESSAGE);

				return;

			} // END IF indexSelectedAccesory

			JOptionPane.showMessageDialog(null, "Se va a eliminar un accesorio.");

			if (JOptionPane.showConfirmDialog(null,
					("Vas a eliminar el accesorio con índice " + indice + ". " + "\n¿Deseas realmente eliminarlo?"),
					"WARNING", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

				accesoriosDAO.borrarAccesorio(indice);

			} else {
				loadListPanel();
			}

			loadListPanel();

			// GUARDAR CAMBIOS ACCESORIO
		} else if (selection == editWindow.getBtnModificar()) {

			String tipo = null;
			String marca = "";
			String modelo = "";
			String gama = null;
			String precio = "";
			double precioDouble = 0.0;

			boolean correcto = false;

			int indiceTipo = editWindow.getEditComboTipo().getSelectedIndex();
			int indiceGama = editWindow.getEditComboGama().getSelectedIndex();

			// VALIDAR COMBO TIPO
			System.out.printf("El indice seleccionado es %d\n", indiceTipo);

			if (indiceTipo <= 0) {

				correcto = false;
				JOptionPane.showMessageDialog(null, "Debe elegir una opción de las mostradas", "TIPO DE ACCESORIO",
						JOptionPane.ERROR_MESSAGE);
				return;

			} else if (indiceTipo > 0) {

				tipo = editWindow.getEditComboTipo().getSelectedItem().toString();
				correcto = true;
			} // end if indiceTipo

			// VALIDAR MARCA
			marca = editWindow.getEditMarca().getText();

			if (!textoValido(marca) || marca.isEmpty()) {

				correcto = false;
				JOptionPane.showMessageDialog(null, "Debe introducir un texto correcto para la marca.",
						"DATO ERRÓNEO MARCA", JOptionPane.ERROR_MESSAGE);
				return;

			} else {

				correcto = true;

			} // end if marca

			// VALIDAR MODELO
			modelo = editWindow.getEditModelo().getText();

			if (!textoValido(modelo) || modelo.isEmpty()) {

				correcto = false;
				JOptionPane.showMessageDialog(null, "Debe introducir un texto correcto para el modelo.",
						"DATO ERRÓNEO MODELO", JOptionPane.ERROR_MESSAGE);
				return;

			} else {

				correcto = true;

			} // end if modelo

			// VALIDAR COMBO GAMA
			if (indiceGama <= 0) {

				JOptionPane.showMessageDialog(null, "Debe elegir una opción de las mostradas", "GAMA ACCESORIO",
						JOptionPane.ERROR_MESSAGE);
				return;

			} else if ((indiceGama > 0)) {

				gama = insertWindow.getComboGama().getSelectedItem().toString();
				correcto = true;

			} // end if indiceGama

			// VALIDAR PRECIO

			precio = editWindow.getEditPrecio().getText().replace(",", ".");

			if (!decimalValido(precio) || precio.isEmpty()) {

				correcto = false;
				JOptionPane.showMessageDialog(null, "Debe introducir un valor correcto para el precio.",
						"DATO ERRÓNEO PRECIO", JOptionPane.ERROR_MESSAGE);
				return;

			} else {
				precioDouble = Double.parseDouble(precio);
				correcto = true;
			} // END IF VALIDAR PRECIO

			String soporte = "NO";

			if (editWindow.getEditRdbtnSi().isSelected()) {

				soporte = "SI";
			} // END ID SOPORTE

			
			if (correcto == true) {
			accesoriosDAO.actualizarAccesorioPorIndice(tipo, marca, modelo, gama, precioDouble, soporte,
					indexSelectedAccesory);

			loadListPanel();
			} // END IF CORRECTO
		}

		SwingUtilities.updateComponentTreeUI(mainWindow);

	} // END actionPerformed
// ************************************************************************
	
	// Imagen de fondo inicio
	public class ImagenFondoPanel extends JPanel {

		@Override
		public void paint(Graphics g) {
			Image imagen = new ImageIcon(this.getClass().getResource("/img/bg_04.jpg")).getImage();
			g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
			setOpaque(false);
			super.paint(g);
		}

	} // END ImagenFondoPanel

	// *********************** MÉTODOS ************************************

	// Panel registrar nuevo accesorio
	private void loadInsertPanel() {

		mainWindow.setContentPane(insertWindow);

		insertWindow.getComboTipo().setSelectedIndex(0);
		insertWindow.getMarca().setText("");
		insertWindow.getModelo().setText("");
		insertWindow.getComboGama().setSelectedIndex(0);
		insertWindow.getPrecio().setText("");
		insertWindow.getRbnNo().setSelected(true);
	}

	// Panel listar accesorios
	private void loadListPanel() {

		mainWindow.setContentPane(listWindow);

		ArrayList<Accesorio> accesorios = accesoriosDAO.obtenerAccesorios();

		DefaultListModel<String> listAcc = new DefaultListModel<String>();

		for (Accesorio a : accesorios) {

			listAcc.addElement(a.toString());
		}

		listWindow.getListAccesory().setModel(listAcc);
	}

	// Panel editar accesorio
	private void loadEditPanel() {

		mainWindow.setContentPane(editWindow);

	} // END

	// REGEX VALIDAR TEXTO
	static boolean textoValido(String texto) {
		String regex = "^[0-9a-zA-ZáéíóúÁÉÍÓÚñÑ ]{2,40}$";
		return texto.matches(regex);

	} // END VALIDAR TEXTO

	// REGEX VALIDAR DECIMAL
	static boolean decimalValido(String decimal) {
		String regex = "^[1-9]{1}[0-9]{0,3}[,/.][0-9]{1,2}$";
		return decimal.matches(regex);

	} // END VALIDAR DECIMAL

	// pattern="^[0-9a-zA-ZáéíóúÁÉÍÓÚñÑ]{2,30}$" regex para texto
	// pattern="^[1-9]{1}[0-9]{0,1}[,/.][0-9]{1,2}$" regex para decimales
	// regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$"; regex email
	

} // END WindowsManager
