package vista;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import java.awt.SystemColor;
import javax.swing.SwingConstants;

public class EditWindow extends JPanel {
	private JTextField editMarca;
	private JTextField editModelo;
	private JTextField EditPrecio;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JComboBox editComboTipo;
	private JComboBox EditComboGama;
	private JRadioButton editRdbtnSi;
	private JRadioButton editRdbtnNo;
	private JButton btnModificar;

	/**
	 * Create the panel.
	 */
	public EditWindow() {
		setPreferredSize(new Dimension(450, 520));
		setBackground(SystemColor.activeCaption);
		setBorder(null);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("EDITAR ACCESORIO");
		lblNewLabel.setForeground(SystemColor.textHighlight);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(132, 27, 194, 35);
		add(lblNewLabel);
		
		editComboTipo = new JComboBox();
		editComboTipo.setToolTipText("Es obligatorio seleccionar una opción del listado.");
		editComboTipo.setFont(new Font("Tahoma", Font.BOLD, 12));
		editComboTipo.setModel(new DefaultComboBoxModel(new String[] {"Selecciona una opción", "Audio", "Teclados", "Ratones", "Monitores", "Streaming", "Accesorios periféricos"}));
		editComboTipo.setBounds(217, 93, 178, 22);
		add(editComboTipo);
		
		JLabel lblNewLabel_1 = new JLabel("Tipo de accesorio");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(53, 91, 144, 22);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Marca");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(53, 138, 144, 22);
		add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Modelo");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_2.setBounds(53, 186, 144, 22);
		add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Gama");
		lblNewLabel_1_3.setBorder(null);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_3.setBounds(53, 228, 144, 22);
		add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Precio");
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_4.setBounds(53, 277, 144, 22);
		add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Extensión garantía");
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_5.setBounds(53, 334, 144, 22);
		add(lblNewLabel_1_5);
		
		editMarca = new JTextField();
		editMarca.setToolTipText("Introduce la marca del accesorio. Sólo se admiten caracteres y números, máximo 40.");
		editMarca.setBorder(null);
		editMarca.setForeground(SystemColor.textHighlight);
		editMarca.setFont(new Font("Tahoma", Font.BOLD, 11));
		editMarca.setBounds(217, 141, 178, 20);
		add(editMarca);
		editMarca.setColumns(10);
		
		editModelo = new JTextField();
		editModelo.setToolTipText("Introduce el modelo del accesorio. Sólo se admiten caracteres y números, máximo 40.");
		editModelo.setBorder(null);
		editModelo.setForeground(SystemColor.textHighlight);
		editModelo.setFont(new Font("Tahoma", Font.BOLD, 11));
		editModelo.setColumns(10);
		editModelo.setBounds(217, 189, 178, 20);
		add(editModelo);
		
		EditPrecio = new JTextField();
		EditPrecio.setToolTipText("Formato admitido ####,## ó ####.##");
		EditPrecio.setHorizontalAlignment(SwingConstants.TRAILING);
		EditPrecio.setBorder(null);
		EditPrecio.setForeground(SystemColor.textHighlight);
		EditPrecio.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		EditPrecio.setColumns(10);
		EditPrecio.setBounds(217, 280, 178, 20);
		add(EditPrecio);
		
		EditComboGama = new JComboBox();
		EditComboGama.setToolTipText("Es obligatorio seleccionar una opción del listado.");
		EditComboGama.setFont(new Font("Tahoma", Font.BOLD, 12));
		EditComboGama.setModel(new DefaultComboBoxModel(new String[] {"Selecciona una opción", "Basic", "Advance", "Elite"}));
		EditComboGama.setBounds(217, 230, 178, 22);
		add(EditComboGama);
		
		editRdbtnSi = new JRadioButton("SI");
		editRdbtnSi.setOpaque(false);
		buttonGroup.add(editRdbtnSi);
		editRdbtnSi.setFont(new Font("Tahoma", Font.BOLD, 14));
		editRdbtnSi.setForeground(SystemColor.textHighlight);
		editRdbtnSi.setBounds(214, 336, 49, 23);
		add(editRdbtnSi);
		
		editRdbtnNo = new JRadioButton("No");
		editRdbtnNo.setOpaque(false);
		buttonGroup.add(editRdbtnNo);
		editRdbtnNo.setForeground(new Color(204, 51, 0));
		editRdbtnNo.setFont(new Font("Tahoma", Font.BOLD, 14));
		editRdbtnNo.setBounds(346, 336, 49, 23);
		add(editRdbtnNo);
		
		btnModificar = new JButton("MODIFICAR");
		btnModificar.setBounds(187, 411, 100, 23);
		add(btnModificar);

	}
	
	
	public JComboBox getEditComboTipo() {
		return editComboTipo;
	}
	public JTextField getEditMarca() {
		return editMarca;
	}
	public JTextField getEditModelo() {
		return editModelo;
	}
	public JComboBox getEditComboGama() {
		return EditComboGama;
	}
	public JTextField getEditPrecio() {
		return EditPrecio;
	}
	public JRadioButton getEditRdbtnSi() {
		return editRdbtnSi;
	}
	public JRadioButton getEditRdbtnNo() {
		return editRdbtnNo;
	}
	public JButton getBtnModificar() {
		return btnModificar;
	}
	
}
