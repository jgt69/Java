package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.border.BevelBorder;

public class MainWindow extends JFrame {

	private JPanel contentPane;
	private JMenuItem menuRegistrar;
	private JMenuItem menuListar;
	private JMenu mnMenu;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow frame = new MainWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainWindow() {
		setTitle("GAMING SHOP");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 470, 540);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnMenu = new JMenu("Accesorios");
		menuBar.add(mnMenu);
		
		menuRegistrar = new JMenuItem("Registrar accesorio");
		mnMenu.add(menuRegistrar);
		
		menuListar = new JMenuItem("Mostrar accesorios");
		mnMenu.add(menuListar);
//		contentPane = new JPanel();
//		contentPane.setBorder(null);
//		setContentPane(contentPane);
//		contentPane.setLayout(null);
	}
	public JMenuItem getMenuRegistrar() {
		return menuRegistrar;
	}
	public JMenuItem getMenuListar() {
		return menuListar;
	}
	public JMenu getMainMenu() {
		return mnMenu;
	}
}
