package vista;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.ListSelectionModel;
import java.awt.SystemColor;
import javax.swing.UIManager;

public class ListWindow extends JPanel {
	private JList listAccesory;
	private JButton btnEditar;
	private JButton btnBorrar;

	/**
	 * Create the panel.
	 */
	public ListWindow() {
		setPreferredSize(new Dimension(450, 520));
		setBackground(SystemColor.activeCaption);
		setLayout(null);
		
		JLabel lblListadoDeAccesorios = new JLabel("LISTADO DE ACCESORIOS");
		lblListadoDeAccesorios.setForeground(SystemColor.textHighlight);
		lblListadoDeAccesorios.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblListadoDeAccesorios.setBackground(new Color(102, 102, 102));
		lblListadoDeAccesorios.setBounds(108, 23, 241, 35);
		add(lblListadoDeAccesorios);
		
		listAccesory = new JList();
		listAccesory.setVisibleRowCount(10);
		listAccesory.setValueIsAdjusting(true);
		listAccesory.setSelectionBackground(new Color(255, 255, 225));
		listAccesory.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listAccesory.setSelectedIndex(0);
		listAccesory.setBounds(10, 85, 430, 286);
		
		add(listAccesory);
		
		btnEditar = new JButton("EDITAR");
		btnEditar.setBounds(52, 401, 89, 23);
		add(btnEditar);
		
		btnBorrar = new JButton("ELIMINAR");
		btnBorrar.setBounds(291, 401, 89, 23);
		add(btnBorrar);

	}
	public JList getListAccesory() {
		return listAccesory;
	}
	public JButton getBtnEditar() {
		return btnEditar;
	}
	public JButton getBtnBorrar() {
		return btnBorrar;
	}
}
