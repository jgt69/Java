package vista;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import javax.swing.border.MatteBorder;
import java.awt.SystemColor;
import javax.swing.JFormattedTextField;
import javax.swing.SwingConstants;
import java.awt.Dimension;

public class InsertWindow extends JPanel {
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JComboBox comboTipo;
	private JComboBox comboGama;
	private JRadioButton rdbtnSi;
	private JRadioButton rdbtnNo;
	private JButton btnRegistrar;
	private JFormattedTextField txtMarca;
	private JFormattedTextField txtModelo;
	private JFormattedTextField txtPrecio;

	/**
	 * Create the panel.
	 */
	public InsertWindow() {
		setPreferredSize(new Dimension(450, 520));
		setBackground(SystemColor.activeCaption);
		setBorder(null);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("NUEVO ACCESORIO");
		lblNewLabel.setBackground(new Color(102, 102, 102));
		lblNewLabel.setForeground(SystemColor.textHighlight);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(133, 30, 198, 35);
		add(lblNewLabel);
		
		comboTipo = new JComboBox();
		comboTipo.setToolTipText("Es obligatorio seleccionar una opción del listado.");
		comboTipo.setOpaque(false);
		comboTipo.setFont(new Font("Tahoma", Font.BOLD, 12));
		comboTipo.setModel(new DefaultComboBoxModel(new String[] {"Selecciona una opción", "Audio", "Teclados", "Ratones", "Monitores", "Streaming", "Accesorios periféricos"}));
		comboTipo.setSelectedIndex(0);
		comboTipo.setBounds(217, 93, 178, 22);
		add(comboTipo);
		
		JLabel lblNewLabel_1 = new JLabel("Tipo de accesorio");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(53, 91, 144, 22);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Marca");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(53, 138, 144, 22);
		add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Modelo");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_2.setBounds(53, 186, 144, 22);
		add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Gama");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_3.setBounds(53, 228, 144, 22);
		add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Precio");
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_4.setBounds(53, 277, 144, 22);
		add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Extensión garantía");
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_5.setBounds(53, 334, 144, 22);
		add(lblNewLabel_1_5);
		
		comboGama = new JComboBox();
		comboGama.setToolTipText("Es obligatorio seleccionar una opción del listado.");
		comboGama.setFont(new Font("Tahoma", Font.BOLD, 12));
		comboGama.setModel(new DefaultComboBoxModel(new String[] {"Selecciona una opción", "Basic", "Advance", "Elite"}));
		comboGama.setSelectedIndex(0);
		comboGama.setBounds(217, 230, 178, 22);
		add(comboGama);
		
		rdbtnSi = new JRadioButton("SI");
		rdbtnSi.setOpaque(false);
		buttonGroup.add(rdbtnSi);
		rdbtnSi.setFont(new Font("Tahoma", Font.BOLD, 14));
		rdbtnSi.setForeground(SystemColor.textHighlight);
		rdbtnSi.setBounds(214, 336, 49, 23);
		add(rdbtnSi);
		
		rdbtnNo = new JRadioButton("No");
		rdbtnNo.setOpaque(false);
		rdbtnNo.setSelected(true);
		buttonGroup.add(rdbtnNo);
		rdbtnNo.setForeground(new Color(204, 51, 0));
		rdbtnNo.setFont(new Font("Tahoma", Font.BOLD, 14));
		rdbtnNo.setBounds(346, 336, 49, 23);
		add(rdbtnNo);
		
		btnRegistrar = new JButton("Registrar");
		btnRegistrar.setBounds(184, 418, 89, 23);
		add(btnRegistrar);
		
		txtMarca = new JFormattedTextField();
		txtMarca.setToolTipText("Introduce la marca del accesorio. Sólo se admiten caracteres y números, máximo 40.");
		txtMarca.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtMarca.setForeground(SystemColor.textHighlight);
		txtMarca.setBounds(217, 141, 178, 20);
		add(txtMarca);
		
		txtModelo = new JFormattedTextField();
		txtModelo.setToolTipText("Introduce el modelo del accesorio. Sólo se admiten caracteres y números, máximo 40.");
		txtModelo.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtModelo.setForeground(SystemColor.textHighlight);
		txtModelo.setBounds(217, 189, 178, 20);
		add(txtModelo);
		
		txtPrecio = new JFormattedTextField();
		txtPrecio.setToolTipText("Formato admitido ####,## ó ####.##");
		txtPrecio.setForeground(SystemColor.textHighlight);
		txtPrecio.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		txtPrecio.setHorizontalAlignment(SwingConstants.TRAILING);
		txtPrecio.setBounds(219, 280, 176, 20);
		add(txtPrecio);

	}
	public JComboBox getComboTipo() {
		return comboTipo;
	}
//	public JTextField getMarca() {
//		return txtMarca;
//	}
//	public JTextField getModelo() {
//		return txtModelo;
//	}
	public JComboBox getComboGama() {
		return comboGama;
	}
//	public JTextField getPrecio() {
//		return txtPrecio;
//	}
	public JRadioButton getRbnSi() {
		return rdbtnSi;
	}
	public JRadioButton getRbnNo() {
		return rdbtnNo;
	}
	public JButton getBtnRegistrar() {
		return btnRegistrar;
	}
	public JFormattedTextField getMarca() {
		return txtMarca;
	}
	public JFormattedTextField getModelo() {
		return txtModelo;
	}
	public JFormattedTextField getPrecio() {
		return txtPrecio;
	}
}
