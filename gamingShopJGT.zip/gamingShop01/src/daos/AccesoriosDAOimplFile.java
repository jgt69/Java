package daos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import modelo.Accesorio;

public class AccesoriosDAOimplFile implements AccesoriosDAO{

	private static final String ARCHIVO = "lista.dat";
	
	ArrayList<Accesorio> accesorios = new ArrayList<Accesorio>();

	public AccesoriosDAOimplFile() {
		
		this.cargarArchivo();
	}

	private void cargarArchivo() {
		File ff = new File(ARCHIVO);
		if (ff.exists()) {
			try {
				FileInputStream fin = new FileInputStream(ff);
				ObjectInputStream oin = new ObjectInputStream(fin);
				accesorios = (ArrayList<Accesorio>)oin.readObject();
				oin.close();
				fin.close();
				System.out.println("Se ha finalizado la lectura del archivo correctamente.");
			} catch (IOException e) {
				System.out.println("Un error ha impedido leer el archivo.");
			} catch (ClassNotFoundException e) {
				System.out.println("La clase del objeto no ha sido encontrada.");
			}
		}// end if (f.exists())
		
	}//end cargarArchivo
	

	private void escribirArchivo() {
		
		File ff = new File(ARCHIVO);
		
		try {
			FileOutputStream fou = new FileOutputStream(ff);
			ObjectOutputStream oou = new ObjectOutputStream(fou);
			oou.writeObject(accesorios);
			oou.close();
			fou.close();
			System.out.println("El archivo se ha grabado correctamente.");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
//	private void escribirArchivo() {
//		File ff = new File(ARCHIVO);
//		try {
//			FileOutputStream fou = new FileOutputStream(ff);
//			ObjectOutputStream oou = new ObjectOutputStream(fou);
//			oou.writeObject(accesorios);
//			oou.close();
//			fou.close();
//			System.out.println("El archivo se ha grabado correctamente.");
//		} catch (IOException e) {
//			System.out.println("Un error ha impedido grabar el archivo.");
//		}
//	}

	@Override
	public void registrarAccesorio(Accesorio a) {
		accesorios.add(a);
		escribirArchivo();
		
	}

	@Override
	public ArrayList<Accesorio> obtenerAccesorios() {
		// TODO Auto-generated method stub
		return accesorios;
	}

	@Override
	public void borrarAccesorio(int indice) {
		accesorios.remove(indice);
		escribirArchivo();
		
	}

	@Override
	public Accesorio obtenerAccesorioPorIndice(int indice) {
		
		return accesorios.get(indice);
	}

	@Override
	public void actualizarAccesorioPorIndice(String tipo, String marca, String modelo, String gama, double precio,
			String soporte, int indice) {

		Accesorio a = accesorios.get(indice);
		
		a.setTipo(tipo);
		a.setMarca(marca);
		a.setModelo(modelo);
		a.setGama(gama);
		a.setPrecio(precio);
		a.setSoporte(soporte);
		
		escribirArchivo();
	}
	
	

	

}


