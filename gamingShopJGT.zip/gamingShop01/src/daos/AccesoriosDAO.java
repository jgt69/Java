package daos;

import java.util.ArrayList;

import modelo.Accesorio;

public interface AccesoriosDAO {
	
	public void registrarAccesorio(Accesorio a);
	
	public ArrayList<Accesorio> obtenerAccesorios();
	
	public void borrarAccesorio(int indice);
	
	public Accesorio obtenerAccesorioPorIndice(int indice);
	
	public void actualizarAccesorioPorIndice(
			String tipo, String marca, String modelo, String gama, double precio, String soporte, int indice);
	
}
