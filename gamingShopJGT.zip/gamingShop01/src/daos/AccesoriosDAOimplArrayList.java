package daos;

import java.util.ArrayList;

import modelo.Accesorio;

public class AccesoriosDAOimplArrayList implements AccesoriosDAO{
	
	private ArrayList<Accesorio> accesorios = new ArrayList<Accesorio>();
	
	
	@Override
	public void registrarAccesorio(Accesorio a) {
		accesorios.add(a);
		
	}

	@Override
	public ArrayList<Accesorio> obtenerAccesorios() {
		
		return accesorios;
	}

	@Override
	public void borrarAccesorio(int indice) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Accesorio obtenerAccesorioPorIndice(int indice) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void actualizarAccesorioPorIndice(String tipo, String marca, String modelo, String gama, double precio,
			String soporte, int indice) {
		// TODO Auto-generated method stub
		
	}

}
