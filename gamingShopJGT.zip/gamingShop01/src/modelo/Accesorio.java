package modelo;

import java.io.Serializable;

public class Accesorio implements Serializable {

	private String tipo;
	private String marca;
	private String modelo;
	private String gama;
	private double precio;
	private String soporte;
	private int id;
	
	private static int nextID = 1;
	
	public Accesorio() {

		this.id = nextID++; // Asigna y luego incrementa
		
		
	} // end constructor sin atributos

	public Accesorio(String tipo, String marca, String modelo, String gama, double precio, String soporte) {
		super();
		this.tipo = tipo;
		this.marca = marca;
		this.modelo = modelo;
		this.gama = gama;
		this.precio = precio;
		this.soporte = soporte;
		this.id = nextID++;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getGama() {
		return gama;
	}

	public void setGama(String gama) {
		this.gama = gama;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getSoporte() {
		return soporte;
	}

	public void setSoporte(String soporte) {
		this.soporte = soporte;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public static int getNextID() {
		return nextID;
	}

	public static void setNextID(int proximoID) {
		Accesorio.nextID = proximoID;
	}

	@Override
	public String toString() {
		return "Accesorio [tipo=" + tipo + ", marca=" + marca + ", modelo=" + modelo + ", gama=" + gama + ", precio="
				+ precio + ", soporte=" + soporte + ", id=" + id + "]";
	}
	
	

//	@Override
//	public String toString() {
//		return "Accesorio [" + tipo + " " + marca + " " + modelo + " " + gama + " "
//				+ precio + " " + soporte + "]";
//	}

	


	
	
} // end class
